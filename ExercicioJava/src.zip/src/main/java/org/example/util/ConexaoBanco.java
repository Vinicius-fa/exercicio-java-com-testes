package org.example.util;

import java.sql.Connection;

public class ConexaoBanco {

    public static Connection conectar(){
        return null;
    }
}
